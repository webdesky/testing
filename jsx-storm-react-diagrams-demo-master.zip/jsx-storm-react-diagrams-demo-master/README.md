# Live Demos of Storm React Diagrams 

This project replicates the [Storm React Diagrams ](https://github.com/projectstorm/react-diagrams) examples in JSX style javascript.

Live demo can be found at [https://rickhewes.github.io/jsx-storm-react-diagrams-demo](https://rickhewes.github.io/jsx-storm-react-diagrams-demo/#/) 

To install and build, clone the repo and execute;

``` yarn install && yarn start```
